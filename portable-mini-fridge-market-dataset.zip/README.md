# Portable Mini Fridge Market Dataset

This repository contains a structured dataset based on publicly available information about the  
**Portable Mini Fridge Market**.

## Files Included
- `market_overview.csv` – Market size & CAGR by year
- `segmentation.csv` – Segmentation data (Capacity, Application, Distribution Channel, Region)
- `metadata.json` – Source metadata
- `README.md` – GitHub-style documentation

## Source
https://www.nextmsc.com/report/portable-mini-fridge-market-rc3578
